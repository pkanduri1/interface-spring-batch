package com.truist.batch.config;

import java.util.Map;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskExecutor;
import org.springframework.transaction.PlatformTransactionManager;

import com.truist.batch.listener.GenericJobListener;
import com.truist.batch.listener.GenericStepListener;
import com.truist.batch.mapping.YamlMappingService;
import com.truist.batch.model.BatchJobProperties;
import com.truist.batch.model.FileConfig;
import com.truist.batch.partition.GenericPartitioner;
import com.truist.batch.processor.GenericProcessor;
import com.truist.batch.reader.GenericReader;
import com.truist.batch.tasklet.LoadBatchDateTasklet;
import com.truist.batch.writer.GenericWriter;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Central Spring-bean config for all batch jobs.
 *
 * <ul>
 *   <li>Injects core services: mappingService, jobRepository, transactionManager, config props, listeners, taskExecutor.</li>
 *   <li>Defines a parameterized Job that picks up jobName + sourceSystem at runtime.</li>
 *   <li>Partitions work by FileConfig + YamlMapping.transactionType via GenericPartitioner.</li>
 *   <li>Wires a single chunk-based Step: reader → processor → writer, with fault tolerance.</li>
 * </ul>
 */
@Configuration
@EnableBatchProcessing
@RequiredArgsConstructor
@Slf4j
public class GenericJobConfig {

  // === injected via constructor ===
  private final YamlMappingService         mappingService;
  private final JobRepository              jobRepository;
  private final PlatformTransactionManager transactionManager;
  private final BatchJobProperties         config;
  private final GenericJobListener         jobListener;
  private final GenericStepListener        stepListener;
  private final TaskExecutor               taskExecutor;
  private final LoadBatchDateTasklet       loadBatchDateTasklet;
  
  
  
  @Bean
  public Step loadBatchDateStep() {
      return new StepBuilder("loadBatchDateStep",jobRepository)
          .tasklet(loadBatchDateTasklet,transactionManager)
          .build();
  }


  /**
   * Defines a reusable Job bean.  
   * jobName + sourceSystem come from the launch parameters.
   */
  @Bean
  public Job genericJob() {
      return new org.springframework.batch.core.job.builder.JobBuilder(
                 "genericJob", jobRepository
             )
             .incrementer(new RunIdIncrementer())
             .listener(jobListener)
             .start(loadBatchDateStep())
             .next(filePartitionStep(null, null))
             .build();
  }

  /**
   * Partitions work by each FileConfig and each YamlMapping.transactionType.
   */
  @Bean
  @JobScope
  public Step filePartitionStep(
      @Value("#{jobParameters['jobName']}") String jobName,
      @Value("#{jobParameters['sourceSystem']}") String sourceSystem
  ) {
    // resolve source-system config and job config from application.yml
    var systemConfig = config.getSourceSystem(sourceSystem);
    var jobConfig    = config.getJobConfig(sourceSystem, jobName);

    // our custom partitioner: emits one partition per mapping document
    GenericPartitioner partitioner = new GenericPartitioner(
        mappingService, systemConfig, jobConfig
    );

    return new StepBuilder(jobName + "PartitionStep", jobRepository)
            .partitioner(jobName + "Step", partitioner)
            .step(genericStep())
            .gridSize(config.getGridSize())
            .taskExecutor(taskExecutor)
            .build();
  }

  /**
   * The core chunk step, executed once per partition:
   *   reader → processor → writer
   */
  @Bean
  @StepScope
  public Step genericStep() {
     return new StepBuilder("genericStep", jobRepository)
            .<Map<String,Object>,Map<String,Object>>chunk(config.getChunkSize(), transactionManager)
            .reader(genericReader(null, null))
            .processor(genericProcessor(null))
            .writer(genericWriter(null))
            .listener(stepListener)
            .faultTolerant()
            .skipLimit(10)
            .skip(Exception.class)
            .retryLimit(3)
            .retry(Exception.class)
            .build();
  }

  /**
   * GenericReader: delegates to file-based or JDBC readers based on FileConfig.params.format.
   * Injects the DataSource so JdbcRecordReader can execute custom SQL.
   */
  @Bean
  @StepScope
  public GenericReader genericReader(
      @Value("#{stepExecutionContext['fileConfig']}") FileConfig fileConfig,
      DataSource dataSource
  ) {
    return new GenericReader(fileConfig, dataSource);
  }

  /**
   * GenericProcessor: applies YamlMappingService rules to each record.
   */
  @Bean
  @StepScope
  public GenericProcessor genericProcessor(
      @Value("#{stepExecutionContext['fileConfig']}") FileConfig fileConfig
  ) {
    return new GenericProcessor(fileConfig, mappingService);
  }

  /**
   * GenericWriter: builds fixed-width lines from transformed maps.
   */
  @Bean
  @StepScope
  public GenericWriter genericWriter(
      @Value("#{stepExecutionContext['fileConfig']}") FileConfig fileConfig
  ) {
    return new GenericWriter(mappingService, fileConfig);
  }
}