package com.truist.batch.config;



class TableNameValidator{

    void validate(String tableName) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
	
}