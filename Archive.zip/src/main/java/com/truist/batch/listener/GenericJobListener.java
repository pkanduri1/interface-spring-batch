package com.truist.batch.listener;


import java.sql.Timestamp;

import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;




@Component
@Slf4j
public class GenericJobListener implements JobExecutionListener {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public void beforeJob(JobExecution jobExecution) {
        log.info("Starting job '{}' with parameters {}", 
            jobExecution.getJobInstance().getJobName(), 
            jobExecution.getJobParameters().toString());
    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        long readCount = jobExecution.getStepExecutions().stream()
            .mapToLong(se -> se.getReadCount()).sum();
        long writeCount = jobExecution.getStepExecutions().stream()
            .mapToLong(se -> se.getWriteCount()).sum();
        long skipCount = jobExecution.getStepExecutions().stream()
            .mapToLong(se -> se.getReadSkipCount() + se.getProcessSkipCount() + se.getWriteSkipCount()).sum();
        log.info("Job '{}' finished with status {}. Read={}, Written={}, Skipped={}", 
            jobExecution.getJobInstance().getJobName(), 
            jobExecution.getStatus(), readCount, writeCount, skipCount);

        // Insert job-level audit record
        String sql = "INSERT INTO BATCH_JOB_AUDIT "
            + "(JOB_NAME, STATUS, READ_COUNT, WRITE_COUNT, SKIP_COUNT, START_TIME, END_TIME) "
            + "VALUES (?, ?, ?, ?, ?, ?, ?)";
        String jobName = jobExecution.getJobInstance().getJobName();
        String status = jobExecution.getStatus().toString();
        Timestamp startTime = Timestamp.valueOf(jobExecution.getStartTime());
        Timestamp endTime = Timestamp.valueOf(jobExecution.getEndTime());
        jdbcTemplate.update(sql,
            jobName,
            status,
            readCount,
            writeCount,
            skipCount,
            startTime,
            endTime
        );
    }
}
