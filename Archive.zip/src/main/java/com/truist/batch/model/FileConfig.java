package com.truist.batch.model;

import java.util.List;
import java.util.Map;

import lombok.Data;

/**
 * Configuration for a single input file (and its transaction types) to process.
 */
@Data
public class FileConfig {

    /** Path to the input file */
    private String inputPath;

    /** Transaction types inside the file (if multiTxn=true) */
    private List<String> transactionTypes;

    /** FreeMarker template or mapping key to use */
    private String template;

    /** Target staging table or writer identifier */
    private String target;

    /** Additional parameters (e.g., delimiter) */
    private Map<String, String> params;
}
