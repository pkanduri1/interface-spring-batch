package com.truist.batch.model;

import java.util.List;

import lombok.Data;

/**
 * Configuration for a specific batch job under a source system.
 */
@Data
public class JobConfig {

    /** Files to process for this job */
    private List<FileConfig> files;

    /** If true, each file contains multiple transaction types */
    private boolean multiTxn;
}
