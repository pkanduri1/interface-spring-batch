package com.truist.batch.model;

import lombok.Data;

@Data
public class SourceTables {
    private String master;

}
