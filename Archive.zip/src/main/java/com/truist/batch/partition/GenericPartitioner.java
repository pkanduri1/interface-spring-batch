package com.truist.batch.partition;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.batch.core.partition.support.Partitioner;
import org.springframework.batch.item.ExecutionContext;

import com.truist.batch.mapping.YamlMappingService;
import com.truist.batch.model.FileConfig;
import com.truist.batch.model.SourceSystemConfig;
import com.truist.batch.model.YamlMapping;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class GenericPartitioner implements Partitioner {

  private final YamlMappingService mappingService;
  private final SourceSystemConfig systemConfig;
  private final com.truist.batch.model.JobConfig jobConfig;

  @Override
  public Map<String, ExecutionContext> partition(int gridSize) {
    Map<String, ExecutionContext> partitions = new HashMap<>();
    for (FileConfig file : jobConfig.getFiles()) {
      List<YamlMapping> docs = mappingService.loadYamlMappings(file.getTemplate());
      for (YamlMapping doc : docs) {
        String txn = doc.getTransactionType();
        ExecutionContext context = new ExecutionContext();
        context.put("fileConfig", file);
        if (txn != null && !txn.equalsIgnoreCase("default")) {
          context.putString("transactionType", txn);
        }
        String key = file.getInputPath() + (txn != null ? "[" + txn + "]" : "");
        partitions.put(key, context);
      }
    }
    return partitions;
  }
}
