package com.truist.batch.writer;

import com.truist.batch.mapping.YamlMappingService;
import com.truist.batch.model.FieldMapping;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemStream;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.core.io.FileSystemResource;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Writes records to a fixed-width file based on mapping definitions.
 */
@Slf4j
@RequiredArgsConstructor
public class FixedWidthFileWriter implements ItemWriter<String>, ItemStream {

    private final YamlMappingService mappingService;
    private final String template;      // mapping YAML path
    private final String outputPath;    // file system path to write
    private FlatFileItemWriter<String> delegate;
    private List<Map.Entry<String, FieldMapping>> mappings;

    @Override
    public void open(ExecutionContext executionContext) throws ItemStreamException {
        // Load and sort mappings once per job execution
        mappings = mappingService.loadFieldMappings(template);
        // Initialize delegate writer for String lines
        delegate = new FlatFileItemWriter<>();
        delegate.setResource(new FileSystemResource(outputPath));
        delegate.setName("FixedWidthFileWriter");
        delegate.setAppendAllowed(false);
        // As mappingService.transformField already pads values, identity aggregator suffices
        delegate.setLineAggregator(line -> line);
        delegate.open(executionContext);
    }

    @Override
    public void write(Chunk<? extends String> chunk) throws Exception {
        // Map each record to a fixed-width string
       
        delegate.write(chunk);
    }

    public String mapRecord(Map<String, Object> row) {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, FieldMapping> entry : mappings) {
            FieldMapping m = entry.getValue();
            String val = mappingService.transformField(row, m);
            sb.append(val);
        }
        return sb.toString();
    }

    @Override
    public void update(ExecutionContext executionContext) throws ItemStreamException {
        delegate.update(executionContext);
    }

    @Override
    public void close() throws ItemStreamException {
        delegate.close();
    }
}