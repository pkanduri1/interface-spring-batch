package com.truist.batch.writer;

import java.io.File;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemStream;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.batch.item.ItemWriter;

import com.truist.batch.mapping.YamlMappingService;
import com.truist.batch.model.FieldMapping;
import com.truist.batch.model.FileConfig;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class GenericWriter
        implements ItemWriter<Map<String, Object>>, ItemStream {

    private FixedWidthFileWriter delegate;
    private final YamlMappingService yamlMappingService;
    private final FileConfig fileConfig;
    private List<Map.Entry<String, FieldMapping>> mappings;

    @Override
    public void write(Chunk<? extends Map<String, Object>> chunk) throws Exception {
        List<String> lines = chunk.getItems().stream().map(record -> {
            StringBuilder sb = new StringBuilder();
            for (Map.Entry<String, FieldMapping> entry : mappings) {
                sb.append(yamlMappingService.transformField(record, entry.getValue()));
            }
            return sb.toString();
        }).collect(Collectors.toList());
        Chunk<String> strChunk = new Chunk<>(lines);
        delegate.write(strChunk);
    }

    @Override
    public void open(ExecutionContext executionContext)
            throws ItemStreamException {
        File outFile = new File(fileConfig.getParams().get("outputPath"));
        File parent = outFile.getParentFile();
        if (parent != null && !parent.exists()) {
            parent.mkdirs();
        }
        mappings = yamlMappingService.loadFieldMappings(fileConfig.getTemplate());
        String outputPath = fileConfig.getParams().get("outputPath");
        delegate = new FixedWidthFileWriter(yamlMappingService, fileConfig.getTemplate(), outputPath);
        delegate.open(executionContext);
    }

    @Override
    public void update(ExecutionContext executionContext)
            throws ItemStreamException {
        delegate.update(executionContext);
    }

    @Override
    public void close() throws ItemStreamException {
        delegate.close();
    }
}
